package com.github.bkhezry.weather.listener;

public interface OnSetApiKeyEventListener {
  void setApiKey();
}
